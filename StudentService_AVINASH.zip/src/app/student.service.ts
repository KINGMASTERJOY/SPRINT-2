import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  API="http://localhost:8080";
  public registerStudent(studentData: any){
    return this.http.post(this.API + '/registerStudent' , studentData);
  }

  public getStudents(){
    return this.http.get(this.API+'/getStudents');
  }

  public deleteStudent(S_id:any){
    return this.http.delete(this.API+'/deleteStudent?S_id=' + S_id);
  }

  public updateStudent(student: any){
    return this.http.put(this.API +'/updateStudents', student);
  }
  constructor(private http: HttpClient) { }
}
